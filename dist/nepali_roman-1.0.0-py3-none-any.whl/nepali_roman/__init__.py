from .romanize import is_devanagari, romanize_text, romanize

name = 'nepali_roman'