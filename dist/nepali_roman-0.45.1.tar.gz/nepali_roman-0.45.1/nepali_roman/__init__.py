from .romanize import romanize_text, romanize

name = 'nepali_roman'